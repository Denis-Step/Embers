//-no-import-rewrite
package plaid.entities;

import java.lang.Object;
import java.lang.String;
import java.lang.Float;
import java.lang.Double;

/**
 * Immutable implementation of {@link PlaidItem}.
 * <p>
 * Use the builder to create immutable instances:
 * {@code ImmutablePlaidItem.builder()}.
 */
@org.immutables.value.Generated(from = "PlaidItem", generator = "Immutables")
@SuppressWarnings({"all"})
@javax.annotation.processing.Generated("org.immutables.processor.ProxyProcessor")
public final class ImmutablePlaidItem implements plaid.entities.PlaidItem {
  private final java.lang.String user;
  private final java.lang.String institutionId;
  private final java.lang.String accessToken;
  private final java.lang.String ID;
  private final java.util.List<java.lang.String> availableProducts;
  private final java.util.List<java.lang.String> accounts;
  private final java.lang.String dateCreated;
  private final java.lang.String metaData;
  private final boolean webhook;
  private final java.lang.String receiverNumber;

  private ImmutablePlaidItem(
      java.lang.String user,
      java.lang.String institutionId,
      java.lang.String accessToken,
      java.lang.String ID,
      java.util.List<java.lang.String> availableProducts,
      java.util.List<java.lang.String> accounts,
      java.lang.String dateCreated,
      java.lang.String metaData,
      boolean webhook,
      java.lang.String receiverNumber) {
    this.user = user;
    this.institutionId = institutionId;
    this.accessToken = accessToken;
    this.ID = ID;
    this.availableProducts = availableProducts;
    this.accounts = accounts;
    this.dateCreated = dateCreated;
    this.metaData = metaData;
    this.webhook = webhook;
    this.receiverNumber = receiverNumber;
  }

  /**
   * @return The value of the {@code user} attribute
   */
  @Override
  public java.lang.String user() {
    return user;
  }

  /**
   * @return The value of the {@code institutionId} attribute
   */
  @Override
  public java.lang.String institutionId() {
    return institutionId;
  }

  /**
   * @return The value of the {@code accessToken} attribute
   */
  @Override
  public java.lang.String accessToken() {
    return accessToken;
  }

  /**
   * @return The value of the {@code ID} attribute
   */
  @Override
  public java.lang.String ID() {
    return ID;
  }

  /**
   * @return The value of the {@code availableProducts} attribute
   */
  @Override
  public java.util.List<java.lang.String> availableProducts() {
    return availableProducts;
  }

  /**
   * @return The value of the {@code accounts} attribute
   */
  @Override
  public java.util.List<java.lang.String> accounts() {
    return accounts;
  }

  /**
   * @return The value of the {@code dateCreated} attribute
   */
  @Override
  public java.lang.String dateCreated() {
    return dateCreated;
  }

  /**
   * @return The value of the {@code metaData} attribute
   */
  @Override
  public java.lang.String metaData() {
    return metaData;
  }

  /**
   * @return The value of the {@code webhook} attribute
   */
  @Override
  public boolean webhook() {
    return webhook;
  }

  /**
   * @return The value of the {@code receiverNumber} attribute
   */
  @Override
  public java.util.Optional<java.lang.String> receiverNumber() {
    return java.util.Optional.ofNullable(receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#user() user} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for user
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withUser(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "user");
    if (this.user.equals(newValue)) return this;
    return new ImmutablePlaidItem(
        newValue,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#institutionId() institutionId} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for institutionId
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withInstitutionId(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "institutionId");
    if (this.institutionId.equals(newValue)) return this;
    return new ImmutablePlaidItem(
        this.user,
        newValue,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#accessToken() accessToken} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for accessToken
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withAccessToken(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "accessToken");
    if (this.accessToken.equals(newValue)) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        newValue,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#ID() ID} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for ID
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withID(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "ID");
    if (this.ID.equals(newValue)) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        newValue,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link PlaidItem#availableProducts() availableProducts}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutablePlaidItem withAvailableProducts(java.lang.String... elements) {
    java.util.List<java.lang.String> newValue = createUnmodifiableList(false, createSafeList(java.util.Arrays.asList(elements), true, false));
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        newValue,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link PlaidItem#availableProducts() availableProducts}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of availableProducts elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutablePlaidItem withAvailableProducts(Iterable<java.lang.String> elements) {
    if (this.availableProducts == elements) return this;
    java.util.List<java.lang.String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        newValue,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link PlaidItem#accounts() accounts}.
   * @param elements The elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutablePlaidItem withAccounts(java.lang.String... elements) {
    java.util.List<java.lang.String> newValue = createUnmodifiableList(false, createSafeList(java.util.Arrays.asList(elements), true, false));
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        newValue,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object with elements that replace the content of {@link PlaidItem#accounts() accounts}.
   * A shallow reference equality check is used to prevent copying of the same value by returning {@code this}.
   * @param elements An iterable of accounts elements to set
   * @return A modified copy of {@code this} object
   */
  public final ImmutablePlaidItem withAccounts(Iterable<java.lang.String> elements) {
    if (this.accounts == elements) return this;
    java.util.List<java.lang.String> newValue = createUnmodifiableList(false, createSafeList(elements, true, false));
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        newValue,
        this.dateCreated,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#dateCreated() dateCreated} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for dateCreated
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withDateCreated(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "dateCreated");
    if (this.dateCreated.equals(newValue)) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        newValue,
        this.metaData,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#metaData() metaData} attribute.
   * An equals check used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for metaData
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withMetaData(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "metaData");
    if (this.metaData.equals(newValue)) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        newValue,
        this.webhook,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a value for the {@link PlaidItem#webhook() webhook} attribute.
   * A value equality check is used to prevent copying of the same value by returning {@code this}.
   * @param value A new value for webhook
   * @return A modified copy of the {@code this} object
   */
  public final ImmutablePlaidItem withWebhook(boolean value) {
    if (this.webhook == value) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        value,
        this.receiverNumber);
  }

  /**
   * Copy the current immutable object by setting a <i>present</i> value for the optional {@link PlaidItem#receiverNumber() receiverNumber} attribute.
   * @param value The value for receiverNumber
   * @return A modified copy of {@code this} object
   */
  public final ImmutablePlaidItem withReceiverNumber(java.lang.String value) {
    java.lang.String newValue = java.util.Objects.requireNonNull(value, "receiverNumber");
    if (java.util.Objects.equals(this.receiverNumber, newValue)) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        newValue);
  }

  /**
   * Copy the current immutable object by setting an optional value for the {@link PlaidItem#receiverNumber() receiverNumber} attribute.
   * An equality check is used on inner nullable value to prevent copying of the same value by returning {@code this}.
   * @param optional A value for receiverNumber
   * @return A modified copy of {@code this} object
   */
  public final ImmutablePlaidItem withReceiverNumber(java.util.Optional<java.lang.String> optional) {
    java.lang.String value = optional.orElse(null);
    if (java.util.Objects.equals(this.receiverNumber, value)) return this;
    return new ImmutablePlaidItem(
        this.user,
        this.institutionId,
        this.accessToken,
        this.ID,
        this.availableProducts,
        this.accounts,
        this.dateCreated,
        this.metaData,
        this.webhook,
        value);
  }

  /**
   * This instance is equal to all instances of {@code ImmutablePlaidItem} that have equal attribute values.
   * @return {@code true} if {@code this} is equal to {@code another} instance
   */
  @Override
  public boolean equals(Object another) {
    if (this == another) return true;
    return another instanceof ImmutablePlaidItem
        && equalTo((ImmutablePlaidItem) another);
  }

  private boolean equalTo(ImmutablePlaidItem another) {
    return user.equals(another.user)
        && institutionId.equals(another.institutionId)
        && accessToken.equals(another.accessToken)
        && ID.equals(another.ID)
        && availableProducts.equals(another.availableProducts)
        && accounts.equals(another.accounts)
        && dateCreated.equals(another.dateCreated)
        && metaData.equals(another.metaData)
        && webhook == another.webhook
        && java.util.Objects.equals(receiverNumber, another.receiverNumber);
  }

  /**
   * Computes a hash code from attributes: {@code user}, {@code institutionId}, {@code accessToken}, {@code ID}, {@code availableProducts}, {@code accounts}, {@code dateCreated}, {@code metaData}, {@code webhook}, {@code receiverNumber}.
   * @return hashCode value
   */
  @Override
  public int hashCode() {
    int h = 5381;
    h += (h << 5) + user.hashCode();
    h += (h << 5) + institutionId.hashCode();
    h += (h << 5) + accessToken.hashCode();
    h += (h << 5) + ID.hashCode();
    h += (h << 5) + availableProducts.hashCode();
    h += (h << 5) + accounts.hashCode();
    h += (h << 5) + dateCreated.hashCode();
    h += (h << 5) + metaData.hashCode();
    h += (h << 5) + java.lang.Boolean.hashCode(webhook);
    h += (h << 5) + java.util.Objects.hashCode(receiverNumber);
    return h;
  }

  /**
   * Prints the immutable value {@code PlaidItem} with attribute values.
   * @return A string representation of the value
   */
  @Override
  public String toString() {
    java.lang.StringBuilder builder = new java.lang.StringBuilder("PlaidItem{");
    builder.append("user=").append(user);
    builder.append(", ");
    builder.append("institutionId=").append(institutionId);
    builder.append(", ");
    builder.append("accessToken=").append(accessToken);
    builder.append(", ");
    builder.append("ID=").append(ID);
    builder.append(", ");
    builder.append("availableProducts=").append(availableProducts);
    builder.append(", ");
    builder.append("accounts=").append(accounts);
    builder.append(", ");
    builder.append("dateCreated=").append(dateCreated);
    builder.append(", ");
    builder.append("metaData=").append(metaData);
    builder.append(", ");
    builder.append("webhook=").append(webhook);
    if (receiverNumber != null) {
      builder.append(", ");
      builder.append("receiverNumber=").append(receiverNumber);
    }
    return builder.append("}").toString();
  }

  /**
   * Creates an immutable copy of a {@link PlaidItem} value.
   * Uses accessors to get values to initialize the new immutable instance.
   * If an instance is already immutable, it is returned as is.
   * @param instance The instance to copy
   * @return A copied immutable PlaidItem instance
   */
  public static ImmutablePlaidItem copyOf(PlaidItem instance) {
    if (instance instanceof ImmutablePlaidItem) {
      return (ImmutablePlaidItem) instance;
    }
    return ImmutablePlaidItem.builder()
        .from(instance)
        .build();
  }

  /**
   * Creates a builder for {@link ImmutablePlaidItem ImmutablePlaidItem}.
   * @return A new ImmutablePlaidItem builder
   */
  public static ImmutablePlaidItem.Builder builder() {
    return new ImmutablePlaidItem.Builder();
  }

  /**
   * Builds instances of type {@link ImmutablePlaidItem ImmutablePlaidItem}.
   * Initialize attributes and then invoke the {@link #build()} method to create an
   * immutable instance.
   * <p><em>{@code Builder} is not thread-safe and generally should not be stored in a field or collection,
   * but instead used immediately to create instances.</em>
   */
  @org.immutables.value.Generated(from = "PlaidItem", generator = "Immutables")
  public static final class Builder {
    private static final long INIT_BIT_USER = 0x1L;
    private static final long INIT_BIT_INSTITUTION_ID = 0x2L;
    private static final long INIT_BIT_ACCESS_TOKEN = 0x4L;
    private static final long INIT_BIT_I_D = 0x8L;
    private static final long INIT_BIT_DATE_CREATED = 0x10L;
    private static final long INIT_BIT_META_DATA = 0x20L;
    private static final long INIT_BIT_WEBHOOK = 0x40L;
    private long initBits = 0x7fL;

    private java.lang.String user;
    private java.lang.String institutionId;
    private java.lang.String accessToken;
    private java.lang.String ID;
    private java.util.List<java.lang.String> availableProducts = new java.util.ArrayList<java.lang.String>();
    private java.util.List<java.lang.String> accounts = new java.util.ArrayList<java.lang.String>();
    private java.lang.String dateCreated;
    private java.lang.String metaData;
    private boolean webhook;
    private java.lang.String receiverNumber;

    private Builder() {
    }

    /**
     * Fill a builder with attribute values from the provided {@code PlaidItem} instance.
     * Regular attribute values will be replaced with those from the given instance.
     * Absent optional values will not replace present values.
     * Collection elements and entries will be added, not replaced.
     * @param instance The instance from which to copy values
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder from(PlaidItem instance) {
      java.util.Objects.requireNonNull(instance, "instance");
      user(instance.user());
      institutionId(instance.institutionId());
      accessToken(instance.accessToken());
      ID(instance.ID());
      addAllAvailableProducts(instance.availableProducts());
      addAllAccounts(instance.accounts());
      dateCreated(instance.dateCreated());
      metaData(instance.metaData());
      webhook(instance.webhook());
      java.util.Optional<java.lang.String> receiverNumberOptional = instance.receiverNumber();
      if (receiverNumberOptional.isPresent()) {
        receiverNumber(receiverNumberOptional);
      }
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#user() user} attribute.
     * @param user The value for user 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder user(java.lang.String user) {
      this.user = java.util.Objects.requireNonNull(user, "user");
      initBits &= ~INIT_BIT_USER;
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#institutionId() institutionId} attribute.
     * @param institutionId The value for institutionId 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder institutionId(java.lang.String institutionId) {
      this.institutionId = java.util.Objects.requireNonNull(institutionId, "institutionId");
      initBits &= ~INIT_BIT_INSTITUTION_ID;
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#accessToken() accessToken} attribute.
     * @param accessToken The value for accessToken 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder accessToken(java.lang.String accessToken) {
      this.accessToken = java.util.Objects.requireNonNull(accessToken, "accessToken");
      initBits &= ~INIT_BIT_ACCESS_TOKEN;
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#ID() ID} attribute.
     * @param ID The value for ID 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder ID(java.lang.String ID) {
      this.ID = java.util.Objects.requireNonNull(ID, "ID");
      initBits &= ~INIT_BIT_I_D;
      return this;
    }

    /**
     * Adds one element to {@link PlaidItem#availableProducts() availableProducts} list.
     * @param element A availableProducts element
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAvailableProducts(java.lang.String element) {
      this.availableProducts.add(java.util.Objects.requireNonNull(element, "availableProducts element"));
      return this;
    }

    /**
     * Adds elements to {@link PlaidItem#availableProducts() availableProducts} list.
     * @param elements An array of availableProducts elements
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAvailableProducts(java.lang.String... elements) {
      for (java.lang.String element : elements) {
        this.availableProducts.add(java.util.Objects.requireNonNull(element, "availableProducts element"));
      }
      return this;
    }


    /**
     * Sets or replaces all elements for {@link PlaidItem#availableProducts() availableProducts} list.
     * @param elements An iterable of availableProducts elements
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder availableProducts(Iterable<java.lang.String> elements) {
      this.availableProducts.clear();
      return addAllAvailableProducts(elements);
    }

    /**
     * Adds elements to {@link PlaidItem#availableProducts() availableProducts} list.
     * @param elements An iterable of availableProducts elements
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAllAvailableProducts(Iterable<java.lang.String> elements) {
      for (java.lang.String element : elements) {
        this.availableProducts.add(java.util.Objects.requireNonNull(element, "availableProducts element"));
      }
      return this;
    }

    /**
     * Adds one element to {@link PlaidItem#accounts() accounts} list.
     * @param element A accounts element
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAccounts(java.lang.String element) {
      this.accounts.add(java.util.Objects.requireNonNull(element, "accounts element"));
      return this;
    }

    /**
     * Adds elements to {@link PlaidItem#accounts() accounts} list.
     * @param elements An array of accounts elements
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAccounts(java.lang.String... elements) {
      for (java.lang.String element : elements) {
        this.accounts.add(java.util.Objects.requireNonNull(element, "accounts element"));
      }
      return this;
    }


    /**
     * Sets or replaces all elements for {@link PlaidItem#accounts() accounts} list.
     * @param elements An iterable of accounts elements
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder accounts(Iterable<java.lang.String> elements) {
      this.accounts.clear();
      return addAllAccounts(elements);
    }

    /**
     * Adds elements to {@link PlaidItem#accounts() accounts} list.
     * @param elements An iterable of accounts elements
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder addAllAccounts(Iterable<java.lang.String> elements) {
      for (java.lang.String element : elements) {
        this.accounts.add(java.util.Objects.requireNonNull(element, "accounts element"));
      }
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#dateCreated() dateCreated} attribute.
     * @param dateCreated The value for dateCreated 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder dateCreated(java.lang.String dateCreated) {
      this.dateCreated = java.util.Objects.requireNonNull(dateCreated, "dateCreated");
      initBits &= ~INIT_BIT_DATE_CREATED;
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#metaData() metaData} attribute.
     * @param metaData The value for metaData 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder metaData(java.lang.String metaData) {
      this.metaData = java.util.Objects.requireNonNull(metaData, "metaData");
      initBits &= ~INIT_BIT_META_DATA;
      return this;
    }

    /**
     * Initializes the value for the {@link PlaidItem#webhook() webhook} attribute.
     * @param webhook The value for webhook 
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder webhook(boolean webhook) {
      this.webhook = webhook;
      initBits &= ~INIT_BIT_WEBHOOK;
      return this;
    }

    /**
     * Initializes the optional value {@link PlaidItem#receiverNumber() receiverNumber} to receiverNumber.
     * @param receiverNumber The value for receiverNumber
     * @return {@code this} builder for chained invocation
     */
    public final Builder receiverNumber(java.lang.String receiverNumber) {
      this.receiverNumber = java.util.Objects.requireNonNull(receiverNumber, "receiverNumber");
      return this;
    }

    /**
     * Initializes the optional value {@link PlaidItem#receiverNumber() receiverNumber} to receiverNumber.
     * @param receiverNumber The value for receiverNumber
     * @return {@code this} builder for use in a chained invocation
     */
    public final Builder receiverNumber(java.util.Optional<java.lang.String> receiverNumber) {
      this.receiverNumber = receiverNumber.orElse(null);
      return this;
    }

    /**
     * Builds a new {@link ImmutablePlaidItem ImmutablePlaidItem}.
     * @return An immutable instance of PlaidItem
     * @throws java.lang.IllegalStateException if any required attributes are missing
     */
    public ImmutablePlaidItem build() {
      if (initBits != 0) {
        throw new java.lang.IllegalStateException(formatRequiredAttributesMessage());
      }
      return new ImmutablePlaidItem(
          user,
          institutionId,
          accessToken,
          ID,
          createUnmodifiableList(true, availableProducts),
          createUnmodifiableList(true, accounts),
          dateCreated,
          metaData,
          webhook,
          receiverNumber);
    }

    private String formatRequiredAttributesMessage() {
      java.util.List<String> attributes = new java.util.ArrayList<>();
      if ((initBits & INIT_BIT_USER) != 0) attributes.add("user");
      if ((initBits & INIT_BIT_INSTITUTION_ID) != 0) attributes.add("institutionId");
      if ((initBits & INIT_BIT_ACCESS_TOKEN) != 0) attributes.add("accessToken");
      if ((initBits & INIT_BIT_I_D) != 0) attributes.add("ID");
      if ((initBits & INIT_BIT_DATE_CREATED) != 0) attributes.add("dateCreated");
      if ((initBits & INIT_BIT_META_DATA) != 0) attributes.add("metaData");
      if ((initBits & INIT_BIT_WEBHOOK) != 0) attributes.add("webhook");
      return "Cannot build PlaidItem, some of required attributes are not set " + attributes;
    }
  }

  private static <T> java.util.List<T> createSafeList(Iterable<? extends T> iterable, boolean checkNulls, boolean skipNulls) {
    java.util.ArrayList<T> list;
    if (iterable instanceof java.util.Collection<?>) {
      int size = ((java.util.Collection<?>) iterable).size();
      if (size == 0) return java.util.Collections.emptyList();
      list = new java.util.ArrayList<>();
    } else {
      list = new java.util.ArrayList<>();
    }
    for (T element : iterable) {
      if (skipNulls && element == null) continue;
      if (checkNulls) java.util.Objects.requireNonNull(element, "element");
      list.add(element);
    }
    return list;
  }

  private static <T> java.util.List<T> createUnmodifiableList(boolean clone, java.util.List<T> list) {
    switch(list.size()) {
    case 0: return java.util.Collections.emptyList();
    case 1: return java.util.Collections.singletonList(list.get(0));
    default:
      if (clone) {
        return java.util.Collections.unmodifiableList(new java.util.ArrayList<>(list));
      } else {
        if (list instanceof java.util.ArrayList<?>) {
          ((java.util.ArrayList<?>) list).trimToSize();
        }
        return java.util.Collections.unmodifiableList(list);
      }
    }
  }
}
